<?php
$name=$_POST['name'];
$visitor_email=$_POST['email'];
$subject=$_POST['subject'];
$message=$_POST['message'];
$email_from = 'gauthamoff@gmail.com';
$email_subject='New submission';
$email_body="User Name:$name.\n"
            "Email:$visitor_email.\n"
            "Subject:$subject.\n"
            "Message:$message.\n";
$to='gauthamganesan4@gmail.com';
$headers="From: $email_from \r\n";
$headers .="Reply-To: $visitor_email \r\n";
mail($to,$email_subject,$email_body,$headers);
header("Location: CONTACT.html");
?>